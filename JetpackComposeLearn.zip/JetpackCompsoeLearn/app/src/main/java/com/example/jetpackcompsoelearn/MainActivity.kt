package com.example.jetpackcompsoelearn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.jetpackcompsoelearn.ui.theme.JetpackCompsoeLearnTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            //HomeScreen()
        }
    }
}

@Composable
fun HomeScreen() {
    Column(modifier = Modifier.padding(12.dp)) {
        Person(name = "Андрей", phone = "88005553535", age = 20)
        Person(name = "Максим", phone = "+79951503365", age = 19)
    }
}


@Composable
fun Person(name: String, phone: String, age: Int) {
    Column {
        Row(modifier = Modifier
            .fillMaxWidth()
            .background(Color.Cyan)) {
            Text(text = name,
                fontSize = 30.sp,
                modifier = Modifier
                    .background(Color.Red)
                    .fillMaxWidth(0.4f),
                textAlign = TextAlign.Center,
                maxLines = 1)
            Text(text = phone, fontSize = 30.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Green),
                textAlign = TextAlign.Right)
        }
        Text(text = age.toString())
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun HomeScreenPreview() {
    HomeScreen()
}